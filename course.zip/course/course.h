/**
 * @file course.h
 * @author Haoxuan Huang
 * @brief This file defines a new type called Course and four functions called "enroll_student", "print_course", "*top_student" and "passing"
 * @version 0.1
 * @date 2022-04-06
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "student.h"
#include <stdbool.h>
 
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


